import 'package:flutter/material.dart';
import 'package:staj_test/Models/Dog.dart';
import 'package:staj_test/DogPage.dart';


void main() {
  runApp(MyApp());
}

//Videodaki asimetrik durumun köpek isimleri ikinci satıra geçince olduğu görülüyor, ama halledemedim...

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Köpek Kütüphanesi',
      home: Scaffold(
      appBar: AppBar(
      title: Text('Köpek Kütüphanesi', style: TextStyle(color: Colors.orange)),
      backgroundColor: Colors.white,
      centerTitle: true,
        ),
  body: FutureBuilder<List<Dog>>(
  future: jsonveri(),
  builder: (context, snapshot) {
    if (snapshot.hasData) {
      return GridView.builder(
    padding: EdgeInsets.all(5),
    itemCount: snapshot.data!.length,
    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 2
       ),
    itemBuilder: (BuildContext context, int index) {
      final dog = snapshot.data![index];

      return GestureDetector(
        onTap: () {
          Navigator.push(context,
            MaterialPageRoute(
              builder: (context) => DogPage(dog),
            ),
          );
        },
        child: Card(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(25),
          ),
          child: Padding(
            padding: EdgeInsets.only(left: 15, right: 15, top: 15),
          child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
          Expanded(
          child: ClipRRect(
         borderRadius: BorderRadius.circular(25),
        child:
         Hero(
          tag: dog.name,
          child: Image.network(
            dog.imageLink,
            fit: BoxFit.cover,
                  ), ),
              ), ),
            Padding(
              padding: EdgeInsets.only(top:15, bottom: 15),
              child: Text(
                dog.name,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
),),],),),),);},
              );} 

    return CircularProgressIndicator();
  },
),
backgroundColor: Colors.orange,
),
);
  }
}

