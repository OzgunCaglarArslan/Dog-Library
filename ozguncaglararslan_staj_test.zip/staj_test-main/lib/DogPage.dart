// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:staj_test/Models/Dog.dart';


class DogPage extends StatelessWidget {
  final Dog dog;

  DogPage(this.dog);

  @override
  Widget build(BuildContext context) {
    var degerler = {
      'Çocuklarla İletişim:': dog.goodWithChildren,
      'Diğer Köpeklerle İletişim:': dog.goodWithOtherDogs,
      "Yabancılarla İletişim:":dog.goodWithStrangers,
      "Tüy Dökme:":dog.shedding,
      "Tüy Bakımı:":dog.grooming,
      "Tüy Uzunluğu:":dog.coatLength,
      "Oyunculuk:":dog.playfulness,
      "Koruyuculuk:":dog.protectiveness,
      "Eğitilebilirlik::":dog.trainability,
      "Enerji:":dog.energy,
      "Havlama:":dog.barking,
      "Maksimum Yaşam Beklentisi:":dog.minLifeExpectancy,
      "Minimum Yaşam Beklentisi:":dog.maxLifeExpectancy
    };

    
var valueWidgets = degerler.entries.map((entry) {
  return Padding(
    padding: EdgeInsets.only(left: 10),
    child: Column(
  crossAxisAlignment: CrossAxisAlignment.start,
     children: [SizedBox(height: 10),
  Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [ Text(
  entry.key,
  style: TextStyle(fontSize: 20),
      ),

      SizedBox(height: 15),

      entry.key == 'Maksimum Yaşam Beklentisi:' || entry.key == 'Minimum Yaşam Beklentisi:'
          ? Text(
              entry.value.toString() + " Yıl",
              style: TextStyle(fontSize: 18),
            )
          : Row(
              children: List.generate(entry.value, (index) => Image.asset('assets/paw_full.png', width: 30, height: 30))
                ..addAll(List.generate(5 - entry.value, (index) => Image.asset('assets/paw_empty.png', width: 30, height: 30))),
            ),

      SizedBox(height: 15),
      
    ],
  ),
        if (entry.key == 'Yabancılarla İletişim:' || entry.key == 'Tüy Uzunluğu:' || entry.key == 'Havlama:')
          Container(
            height: 5,
            color: Colors.orange,
            margin: EdgeInsets.symmetric(vertical: 15),
         
          ),], ), );})
          .toList();



    return Scaffold(
  body: GestureDetector(
    onTap: () {
      Navigator.pop(context); 
},
    child: Container(
      margin: EdgeInsets.all(10),
      decoration: BoxDecoration(
      color: Colors.white,
       borderRadius: BorderRadius.circular(25),
      ),
      child: ListView(
      padding: EdgeInsets.all(15),
       children: <Widget>[
         Hero(
         tag: dog.name,
           child: ClipRRect(
          borderRadius: BorderRadius.circular(25),
            child: 
            Image.network(dog.imageLink, fit: BoxFit.cover),
            ),
          ),
          SizedBox(height: 20),
          Text(
            dog.name,
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            textAlign: TextAlign.center,
          ),
          Container(
            height: 5,
            color: Colors.orange,
            margin: EdgeInsets.symmetric(vertical: 15),
          ),
          
          ...valueWidgets,
        ],
      ),
    ),
),
  backgroundColor: Colors.orange,
); }}