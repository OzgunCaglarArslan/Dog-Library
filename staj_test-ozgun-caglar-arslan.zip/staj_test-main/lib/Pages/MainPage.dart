import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(MyApp());
}

/*
Veri çekip işlemeye çalıştığımda hep hata aldığım için aşağıdaki veriyi ve Widget DogContainer(BuildContext context, int index) {}
kısmındaki verileri python ile çekip, 60 köpeğin verisini hazır olarak kullandım. Ayrıca Dog.dart sayfasını da bu sayfada kullanırken hata aldığım ve düzeltemediğim için oradaki işlemleri de bu sayfada yaptım. Verileri aşağıdaki kodla çektim.

import requests
import json


url = "https://egitim.azurewebsites.net/Dog/GetDogInformation"
response = requests.get(url)
veri = json.loads(response.text)

resim=[]
isim=[]
goodWithChildren=[]
goodWithOtherDogs=[]
shedding=[]
grooming=[]
drooling=[]
coatLength=[]
goodWithStrangers=[]
playfulness=[]
protectiveness=[]
trainability=[]
energy=[]
barking=[]
minLifeExpectancy=[]
maxLifeExpectancy=[]


for i in veri:    
    resim.append(i["imageLink"])
    isim.append(i["name"])
    goodWithChildren.append(i["goodWithChildren"])
    goodWithOtherDogs.append(i["goodWithOtherDogs"])
    shedding.append(i["shedding"])
    grooming.append(i["grooming"])
    drooling.append(i["drooling"])
    coatLength.append(i["coatLength"])
    goodWithStrangers.append(i["goodWithStrangers"])
    playfulness.append(i["playfulness"])
    protectiveness.append(i["protectiveness"])
    trainability.append(i["trainability"])
    energy.append(i["energy"])
    barking.append(i["barking"])
    minLifeExpectancy.append(i["minLifeExpectancy"])
    maxLifeExpectancy.append(i["maxLifeExpectancy"])

    

#değerleri key-value haline getirdim
a=dict(zip(isim,resim))
print(a)

print(goodWithChildren,"\n",goodWithOtherDogs,"\n",shedding,"\n",grooming,"\n",drooling,"\n",coatLength,"\n",goodWithStrangers,"\n",playfulness,"\n",protectiveness,"\n",trainability,"\n",energy,"\n",barking,"\n",minLifeExpectancy,"\n",maxLifeExpectancy,"\n",len(goodWithChildren))
*/


class MyApp extends StatelessWidget {
  final Map<String, String> veri = {
'Field Spaniel': 'https://api-ninjas.com/images/dogs/field_spaniel.jpg', 'Clumber Spaniel': 'https://api-ninjas.com/images/dogs/clumber_spaniel.jpg', 'Flat-Coated Retriever': 'https://api-ninjas.com/images/dogs/flat-coated_retriever.jpg', 'Beagle': 'https://api-ninjas.com/images/dogs/beagle.jpg', 'Bull Terrier': 'https://api-ninjas.com/images/dogs/bull_terrier.jpg', 'Irish Water Spaniel': 'https://api-ninjas.com/images/dogs/irish_water_spaniel.jpg', 'Doberman Pinscher': 'https://api-ninjas.com/images/dogs/doberman_pinscher.jpg', 'Chesapeake Bay Retriever': 'https://api-ninjas.com/images/dogs/chesapeake_bay_retriever.jpg', 'Australian Terrier': 'https://api-ninjas.com/images/dogs/australian_terrier.jpg', 'Cocker Spaniel': 'https://api-ninjas.com/images/dogs/cocker_spaniel.jpg', 'Nova Scotia Duck Tolling Retriever': 'https://api-ninjas.com/images/dogs/nova_scotia_duck_tolling_retriever.jpg', 'Welsh Springer Spaniel': 'https://api-ninjas.com/images/dogs/welsh_springer_spaniel.jpg', 'Jagdterrier': 'https://api-ninjas.com/images/dogs/jagdterrier.jpg', 'Boston Terrier': 'https://api-ninjas.com/images/dogs/boston_terrier.jpg', 'Irish Setter': 'https://api-ninjas.com/images/dogs/irish_setter.jpg', 'Tibetan Spaniel': 'https://api-ninjas.com/images/dogs/tibetan_spaniel.jpg', 'Dalmatian': 'https://api-ninjas.com/images/dogs/dalmatian.jpg', 'Pembroke Welsh Corgi': 'https://api-ninjas.com/images/dogs/pembroke_welsh_corgi.jpg', 'Chihuahua': 'https://api-ninjas.com/images/dogs/chihuahua.jpg', 'American Water Spaniel': 'https://api-ninjas.com/images/dogs/american_water_spaniel.jpg', 'Cairn Terrier': 'https://api-ninjas.com/images/dogs/cairn_terrier.jpg', 'Airedale Terrier': 'https://api-ninjas.com/images/dogs/airedale_terrier.jpg', 'Siberian Husky': 'https://api-ninjas.com/images/dogs/siberian_husky.jpg', 'Biewer Terrier': 'https://api-ninjas.com/images/dogs/biewer_terrier.jpg', 'Akita': 'https://api-ninjas.com/images/dogs/akita.jpg', 'Affenpinscher': 'https://api-ninjas.com/images/dogs/affenpinscher.jpg', 'Afghan Hound': 'https://api-ninjas.com/images/dogs/afghan_hound.jpg', 'Glen of Imaal Terrier': 'https://api-ninjas.com/images/dogs/glen_of_imaal_terrier.jpg', 'Rottweiler': 'https://api-ninjas.com/images/dogs/rottweiler.jpg', 'French Spaniel': 'https://api-ninjas.com/images/dogs/french_spaniel.jpg', 'American Hairless Terrier': 'https://api-ninjas.com/images/dogs/american_hairless_terrier.jpg', 'Irish Red and White Setter': 'https://api-ninjas.com/images/dogs/irish_red_and_white_setter.jpg', 'Chow Chow': 'https://api-ninjas.com/images/dogs/chow_chow.jpg', 'American Staffordshire Terrier': 'https://api-ninjas.com/images/dogs/american_staffordshire_terrier.jpg', 'Black Russian Terrier': 'https://api-ninjas.com/images/dogs/black_russian_terrier.jpg', 'English Cocker Spaniel': 'https://api-ninjas.com/images/dogs/english_cocker_spaniel.jpg', 'Sussex Spaniel': 'https://api-ninjas.com/images/dogs/sussex_spaniel.jpg', 'English Setter': 'https://api-ninjas.com/images/dogs/english_setter.jpg', 'Maltese': 'https://api-ninjas.com/images/dogs/maltese.jpg', 'Golden Retriever': 'https://api-ninjas.com/images/dogs/golden_retriever.jpg', 'Cavalier King Charles Spaniel': 'https://api-ninjas.com/images/dogs/cavalier_king_charles_spaniel.jpg', 'Shiba Inu': 'https://api-ninjas.com/images/dogs/shiba_inu.jpg', 'Gordon Setter': 'https://api-ninjas.com/images/dogs/gordon_setter.jpg', 'Japanese Terrier': 'https://api-ninjas.com/images/dogs/japanese_terrier.jpg', 'Pug': 'https://api-ninjas.com/images/dogs/pug.jpg', 'Cesky Terrier': 'https://api-ninjas.com/images/dogs/cesky_terrier.jpg', 'Dandie Dinmont Terrier': 'https://api-ninjas.com/images/dogs/dandie_dinmont_terrier.jpg', 'Labrador Retriever': 'https://api-ninjas.com/images/dogs/labrador_retriever.jpg', 'Border Terrier': 'https://api-ninjas.com/images/dogs/border_terrier.jpg', 'Boykin Spaniel': 'https://api-ninjas.com/images/dogs/boykin_spaniel.jpg', 'Bedlington Terrier': 'https://api-ninjas.com/images/dogs/bedlington_terrier.jpg', 'Irish Terrier': 'https://api-ninjas.com/images/dogs/irish_terrier.jpg', 'Poodle (Standard)': 'https://api-ninjas.com/images/dogs/poodle_(standard).jpg', 'Lakeland Terrier': 'https://api-ninjas.com/images/dogs/lakeland_terrier.jpg', 'Japanese Akitainu': 'https://api-ninjas.com/images/dogs/japanese_akitainu.jpg', 'Kerry Blue Terrier': 'https://api-ninjas.com/images/dogs/kerry_blue_terrier.jpg', 'English Springer Spaniel': 'https://api-ninjas.com/images/dogs/english_springer_spaniel.jpg', 'Poodle (Miniature)': 'https://api-ninjas.com/images/dogs/poodle_(miniature).jpg', 'English Toy Spaniel': 'https://api-ninjas.com/images/dogs/english_toy_spaniel.jpg', 'Manchester Terrier (Standard)': 'https://api-ninjas.com/images/dogs/manchester_terrier_(standard).jpg'

};













 @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Köpek Kütüphanesi',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Köpek Kütüphanesi', style: TextStyle(color: Colors.orange)),
          backgroundColor: Colors.white,
          centerTitle: true,
        ),
        body: Container(
          color: Colors.orange,
          child: ListView.builder(
            itemCount: (veri.length / 2).ceil(),
            itemBuilder: (context, index) {
              final startIndex = index * 2;
              final endIndex = startIndex + 1;

              return Padding(
                padding: EdgeInsets.symmetric(vertical: 5, horizontal: 5),
                child: Row(
                  children: [
                    Expanded(child: DogContainer(context, startIndex)),
                    if (endIndex < veri.length)
                      SizedBox(width: 5),
                    if (endIndex < veri.length)
                      Expanded(child: DogContainer(context, endIndex)),
                  ],
                )      );  },
          ),
        ),
      ),
    );
  }

  Widget DogContainer(BuildContext context, int index) {
    var goodWithChildren = [5, 3, 5, 5, 3, 3, 5, 3, 5, 5, 5, 5, 3, 5, 5, 5, 3, 3, 1, 3, 3, 3, 5, 3, 3, 3, 3, 3, 3, 5, 5, 5, 3, 3, 3, 5, 3, 4, 3, 5, 5, 3, 3, 0, 5, 5, 3, 5, 5, 5, 3, 5, 5, 3, 0, 4, 3, 5, 5, 4];
    var goodWithOtherDogs =  [4, 3, 5, 5, 1, 3, 3, 3, 3, 5, 4, 4, 3, 4, 5, 3, 3, 4, 3, 3, 3, 3, 5, 5, 1, 3, 3, 3, 3, 5, 3, 5, 2, 3, 3, 5, 3, 4, 3, 5, 5, 3, 3, 0, 4, 3, 3, 5, 3, 5, 3, 1, 3, 3, 0, 2, 4, 3, 5, 3];
    var shedding =  [3, 3, 3, 3, 3, 1, 4, 3, 1, 3, 3, 3, 2, 2, 3, 3, 4, 4, 2, 1, 2, 1, 4, 1, 3, 3, 1, 2, 3, 3, 1, 2, 3, 2, 3, 3, 3, 3, 1, 4, 2, 3, 3, 2, 4, 2, 2, 4, 2, 3, 1, 2, 1, 2, 3, 1, 3, 1, 3, 2];
    var grooming =  [2, 2, 2, 2, 2, 3, 1, 3, 2, 4, 2, 2, 1, 2, 3, 2, 2, 2, 1, 3, 2, 3, 2, 3, 3, 3, 4, 3, 1, 1, 1, 2, 3, 1, 4, 3, 3, 3, 4, 2, 2, 2, 2, 2, 2, 2, 3, 2, 2, 3, 3, 1, 4, 2, 1, 3, 2, 4, 3, 2];
    var drooling =  [2, 4, 2, 1, 1, 2, 2, 2, 1, 2, 2, 2, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 3, 2, 1, 2, 3, 1, 3, 2, 3, 3, 1, 2, 2, 1, 4, 0, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 0, 2, 3, 1, 2, 1];
    var coatLength =  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 2, 1, 1, 1, 2, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1];
    var goodWithStrangers =  [4, 4, 5, 3, 4, 3, 4, 3, 3, 4, 3, 1, 3, 5, 5, 4, 4, 4, 2, 3, 3, 3, 5, 3, 2, 5, 3, 3, 3, 5, 3, 5, 2, 4, 2, 4, 3, 4, 3, 5, 4, 3, 3, 0, 5, 4, 4, 5, 4, 3, 3, 3, 5, 3, 0, 3, 4, 5, 3, 3];
    var playfulness =  [3, 3, 5, 4, 4, 5, 4, 3, 4, 3, 5, 3, 4, 5, 5, 4, 4, 4, 4, 3, 4, 3, 5, 4, 3, 3, 3, 3, 4, 4, 3, 3, 3, 3, 3, 3, 4, 4, 3, 4, 3, 3, 3, 0, 5, 3, 3, 5, 4, 4, 3, 3, 5, 4, 0, 3, 4, 5, 4, 4];
    var protectiveness =  [3, 3, 3, 2, 3, 3, 5, 4, 4, 3, 3, 3, 4, 3, 3, 4, 4, 5, 4, 3, 4, 5, 1, 2, 5, 3, 3, 3, 5, 3, 3, 3, 5, 5, 5, 3, 3, 3, 4, 3, 3, 5, 4, 0, 3, 3, 4, 3, 3, 3, 4, 5, 5, 3, 0, 5, 3, 3, 3, 4];
    var trainability =  [5, 4, 5, 3, 3, 5, 5, 5, 4, 4, 5, 5, 3, 4, 4, 3, 4, 4, 3, 5, 3, 3, 3, 3, 3, 3, 1, 3, 5, 5, 5, 5, 3, 3, 4, 4, 4, 4, 3, 5, 4, 2, 5, 3, 4, 3, 4, 5, 4, 4, 3, 3, 5, 3, 2, 3, 5, 5, 3, 4];
    var energy =  [3, 3, 5, 4, 4, 3, 5, 4, 4, 4, 5, 4, 3, 4, 5, 3, 4, 4, 4, 3, 3, 3, 5, 3, 4, 3, 4, 3, 3, 4, 3, 5, 3, 3, 4, 3, 3, 3, 3, 3, 3, 3, 5, 3, 3, 3, 3, 5, 3, 4, 4, 3, 4, 3, 3, 4, 4, 4, 3, 4];
    var barking =  [3, 1, 3, 4, 3, 1, 3, 3, 5, 3, 2, 3, 1, 2, 3, 3, 3, 4, 5, 3, 4, 3, 5, 3, 2, 3, 3, 2, 1, 3, 3, 3, 1, 3, 3, 3, 3, 3, 3, 1, 3, 3, 3, 0, 1, 3, 3, 3, 3, 3, 3, 3, 4, 3, 0, 4, 3, 4, 2, 4];
    var minLifeExpectancy =  [12, 10, 8, 10, 12, 12, 10, 10, 11, 10, 12, 12, 10, 11, 12, 12, 11, 12, 14, 10, 13, 11, 12, 16, 10, 12, 12, 10, 9, 10, 14, 11, 8, 12, 10, 12, 13, 12, 12, 10, 12, 13, 12, 12, 13, 12, 12, 10, 12, 10, 11, 13, 10, 12, 12, 12, 12, 10, 10, 15];
    var maxLifeExpectancy =  [13, 12, 10, 15, 13, 13, 12, 13, 15, 14, 14, 15, 12, 13, 15, 15, 13, 13, 16, 14, 15, 14, 14, 16, 14, 15, 18, 15, 10, 12, 16, 15, 12, 16, 12, 14, 15, 12, 15, 12, 15, 16, 13, 15, 15, 15, 15, 12, 15, 15, 16, 15, 18, 15, 15, 15, 14, 18, 12, 17];

  return GestureDetector(
  onTap: () {
    Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => DogDetailPage(
          dogName: veri.keys.elementAt(index),
          imageUrl: veri.values.elementAt(index),
          goodWithOtherDogs: goodWithOtherDogs[index],
          shedding: shedding[index],
          goodWithChildren: goodWithChildren[index],
          grooming: grooming[index],
          drooling: drooling[index],
          coatLength: coatLength[index],
          goodWithStrangers: goodWithStrangers[index],
          playfulness: playfulness[index],
          protectiveness: protectiveness[index],
          trainability: trainability[index],
          energy: energy[index],
          barking: barking[index],
          minLifeExpectancy: minLifeExpectancy[index],
          maxLifeExpectancy: maxLifeExpectancy[index],
        ),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          var begin = Offset(0.0, 1.0);
          var end = Offset.zero;
          var curve = Curves.ease;

          var tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
          var offsetAnimation = animation.drive(tween);

          return SlideTransition(
            position: offsetAnimation,
            child: child,
          );
        },
      ),
    );
  },
  child: Container(
    padding: EdgeInsets.all(10.0),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(30),
    ),
    child: Column(
      children: <Widget>[
        Image.network(veri.values.elementAt(index)),
        SizedBox(height: 5),
        Text(
          veri.keys.elementAt(index),
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 20),
        ),
      ],
    ),
  ),
);

  }
}


class DogDetailPage extends StatelessWidget {
  final String dogName;
  final String imageUrl;
  final int goodWithChildren;
  final int goodWithOtherDogs;
  final int shedding;
  final int grooming;
  final int drooling;
  final int coatLength;
  final int goodWithStrangers;
  final int playfulness;
  final int protectiveness;
  final int trainability;
  final int energy;
  final int barking;
  final int minLifeExpectancy;
  final int maxLifeExpectancy;

  

    const DogDetailPage({
    required this.dogName,
    required this.imageUrl,
    required this.goodWithChildren,
    required this.goodWithOtherDogs,
    required this.shedding,
    required this.grooming,
    required this.drooling,
    required this.coatLength,
    required this.goodWithStrangers,
    required this.playfulness,
    required this.protectiveness,
    required this.trainability,
    required this.energy,
    required this.barking,
    required this.minLifeExpectancy,
    required this.maxLifeExpectancy,
 
  });

@override
Widget build(BuildContext context) {
  List<Map<String, dynamic>> variables = [
    {'name': 'Çocuklarla İletişim', 'value': goodWithChildren},
    {'name': 'Diğer Köpeklerle İletişim', 'value':goodWithOtherDogs},
    {'name': 'Yabancılarla İletişim', 'value': goodWithStrangers},
    {'name': 'Tüy Bakımı', 'value': grooming},
    {'name': 'Tüy Uzunluğu', 'value': coatLength},
    {'name': 'Tüy Dökme', 'value': shedding},
    {'name': 'Salya', 'value': drooling},
    {'name': 'Oyunculuk', 'value': playfulness},
    {'name': 'Koruyuculuk', 'value': protectiveness},
    {'name': 'Eğitilebilirlik', 'value': trainability},
    {'name': 'Enerji', 'value': energy},
    {'name': 'Havlama', 'value': barking},
    {'name': 'Min Yaşam Süresi', 'value': minLifeExpectancy},
    {'name': 'Max Yaşam Süresi', 'value': maxLifeExpectancy},
  ];

  List<Widget> pawIcons = variables.map((variable) {
    List<Widget> icons = List.generate(
      5,
      (index) => index < variable['value']
          ? Image.asset(
              'assets/paw_full.png',
              width: 20,
              height: 20,
            )
          : Image.asset(
              'assets/paw_empty.png',
              width: 20,
              height: 20,
            ),
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            '${variable['name']}:',
            style: TextStyle(fontSize: 16, color: Colors.black),
          ),
        ),
        SizedBox(height: 20),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: icons,
          ),
        ),
        SizedBox(height: 40),
      ],
    );
  }).toList();

  return Container(
    margin: EdgeInsets.all(5),
    decoration: BoxDecoration(
      color: Colors.orange,
      borderRadius: BorderRadius.circular(20),
    ),
    child: Padding(
      padding: EdgeInsets.all(15),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
             crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Container(
                    height: 200,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                      image: DecorationImage(
                      image: NetworkImage(imageUrl),
                      fit:BoxFit.cover           
                     
                ),),),

                  SizedBox(height: 20),
                  Align(
                    alignment: Alignment.center,
                    child: Padding(
                      padding: EdgeInsets.only(bottom: 20),
                      child: Text(
                        dogName,
                        style: TextStyle(fontSize: 16, color: Colors.black),
                      ),  ), ),
                  SizedBox(height: 20),
                  ...pawIcons,
                  SizedBox(height: 10),
                  Container(
                    height: 5,
                    margin: EdgeInsets.symmetric(horizontal: 10),
                    color: Colors.orange,
                  ),
                  SizedBox(height: 10),
                ],
              ),),
          ],
        ),
      ),
    ),);
}
}