import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final Map<String, String> veri = {
    'Border Terrier': 'https://api-ninjas.com/images/dogs/border_terrier.jpg',

  };

      
      
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Köpek Uygulaması',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Köpek Kütüphanesi', style: TextStyle(color: Colors.orange)),
          backgroundColor: Colors.white,
          centerTitle: true,
        ),
        
      ),
    );
  }
  }



