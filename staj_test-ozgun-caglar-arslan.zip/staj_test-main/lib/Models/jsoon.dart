import 'package:http/http.dart' as http;
import 'dart:convert';

Future<void> fetchDataFromWebsite() async {
  var url = Uri.parse('https://egitim.azurewebsites.net/Dog/GetDogInformation');

  var response = await http.get(url);

  if (response.statusCode == 200) {
    var jsonData = response.body;
    var data = json.decode(jsonData);

  } else {
    print('${response.statusCode}');
  }
}